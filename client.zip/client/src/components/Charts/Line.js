export const LineGraph = () =>{
    return <>LineGraph</>
}