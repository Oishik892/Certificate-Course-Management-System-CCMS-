import React, { useState, useCallback, useRef } from "react";
import "./certificate.css";
import certificateTemplate from "./certificate.png";
import { toPng } from "html-to-image";

// Define the interface for props
interface CertificateProps {
  name: string;
  course: string;
}

// Modify the component to accept props
const Certificate: React.FC<CertificateProps> = ({ name, course }) => {
  const ref = useRef<HTMLDivElement>(null);
    name = 'Sahib Abbas Bahar Chowdhury'
    course = "Database Management Systems"
  const onButtonClick = useCallback(() => {
    if (ref.current === null) {
      return;
    }

    toPng(ref.current, { cacheBust: true })
      .then((dataUrl: string) => {
        const link = document.createElement("a");
        link.download = "certificate.png";
        link.href = dataUrl;
        link.click();
      })
      .catch((err: any) => {
        console.error(err);
      });
  }, [ref]);

  return (
    <div className="container-fluid flex-fill" style={{
      backgroundImage: `url('bg_8(1).jpg')`,
      backgroundSize: "cover",
      backgroundPosition: "center",
    }}>
      <div className="container" ref={ref}>
        <img
          src={certificateTemplate}
          alt="Certificate Template"
          height={500}
        />
        <div className="content">
          <h1>{name}</h1>
          <p>{course}</p>
        </div>
      </div>
      <button onClick={onButtonClick}>Take a Picture</button>
      <button className="back" onClick={onButtonClick}>Go Back</button>
    </div>
  );
};

export default Certificate;
